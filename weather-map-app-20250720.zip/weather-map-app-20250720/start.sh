#!/bin/bash
echo "🌦️ Starting Weather Map App..."
echo "🌐 Open: http://localhost:8001/weather-map-modular.html"
echo "🔄 Press Ctrl+C to stop"
python3 -m http.server 8001
