/**
 * Map Controller Module - Extracted from monolithic code
 * Handles all Leaflet map interactions, markers, and layers
 * 
 * Following scanner.rs refactoring pattern:
 * - Single responsibility: map visualization and interaction
 * - Clean separation from UI state and weather data
 * - Mobile-optimized map controls and markers
 * - Clustered markers for performance
 */

class MapController {
    constructor(containerId, options = {}) {
        this.containerId = containerId;
        this.options = {
            center: options.center || [43.7, 3.5],
            zoom: options.zoom || 7,
            maxZoom: options.maxZoom || 18,
            clusterRadius: options.clusterRadius || 50,
            ...options
        };
        
        // Map and layer references
        this.map = null;
        this.baseLayers = {};
        this.overlayLayers = {};
        
        // Data layers
        this.weatherLayer = L.layerGroup();
        this.activitiesLayer = L.markerClusterGroup({
            chunkedLoading: true,
            spiderfyOnMaxZoom: true,
            showCoverageOnHover: false,
            zoomToBoundsOnClick: true,
            maxClusterRadius: this.options.clusterRadius
        });
        this.routeLayer = L.layerGroup();
        
        // State
        this.currentWeatherData = null;
        this.currentDayIndex = 0;
        this.showOnlyDry = false;
        this.activeActivities = [];
        this.visibleActivities = new Set();
        
        // Event handlers storage
        this.eventHandlers = new Map();
        
        this.initializeMap();
        this.setupEventListeners();
    }
    
    /**
     * Initialize the Leaflet map
     * @private
     */
    initializeMap() {
        try {
            // Create map with mobile-optimized settings
            this.map = L.map(this.containerId, {
                center: this.options.center,
                zoom: this.options.zoom,
                zoomControl: false,
                tap: true,
                touchZoom: true,
                doubleClickZoom: true,
                scrollWheelZoom: true,
                boxZoom: false // Disabled for mobile
            });
            
            // Add zoom control in bottom-right
            L.control.zoom({ position: 'bottomright' }).addTo(this.map);
            
            // Setup base layers
            this.setupBaseLayers();
            
            // Add data layers to map
            this.map.addLayer(this.weatherLayer);
            this.map.addLayer(this.activitiesLayer);
            this.map.addLayer(this.routeLayer);
            
            console.log('MapController: Map initialized successfully');
            
        } catch (error) {
            console.error('MapController: Failed to initialize map:', error);
            throw new Error('Impossible d\'initialiser la carte');
        }
    }
    
    /**
     * Setup base map layers
     * @private
     */
    setupBaseLayers() {
        // CartoDB Voyager - clean and mobile-friendly
        this.baseLayers.carto = L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
            attribution: '© CARTO © OpenStreetMap contributors',
            subdomains: 'abcd',
            maxZoom: this.options.maxZoom
        });
        
        // OpenStreetMap fallback
        this.baseLayers.osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: this.options.maxZoom
        });
        
        // Satellite imagery for outdoor activities
        this.baseLayers.satellite = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: '© Esri',
            maxZoom: this.options.maxZoom
        });
        
        // Add default layer
        this.baseLayers.carto.addTo(this.map);
        
        // Add layer control if multiple base layers
        if (Object.keys(this.baseLayers).length > 1) {
            L.control.layers(this.baseLayers, this.overlayLayers, {
                position: 'topright',
                collapsed: true
            }).addTo(this.map);
        }
    }
    
    /**
     * Setup event listeners
     * @private
     */
    setupEventListeners() {
        // Map click events
        this.map.on('click', (e) => {
            this.emit('mapClicked', { 
                latlng: e.latlng,
                containerPoint: e.containerPoint 
            });
        });
        
        // Map zoom events
        this.map.on('zoomend', () => {
            this.emit('mapZoomed', { 
                zoom: this.map.getZoom(),
                bounds: this.map.getBounds()
            });
        });
        
        // Map move events (throttled)
        let moveTimeout;
        this.map.on('moveend', () => {
            clearTimeout(moveTimeout);
            moveTimeout = setTimeout(() => {
                this.emit('mapMoved', {
                    center: this.map.getCenter(),
                    bounds: this.map.getBounds(),
                    zoom: this.map.getZoom()
                });
            }, 150);
        });
        
        // Handle map resize for mobile orientation changes
        window.addEventListener('orientationchange', () => {
            setTimeout(() => {
                this.map.invalidateSize();
            }, 100);
        });
        
        window.addEventListener('resize', () => {
            this.map.invalidateSize();
        });
    }
    
    /**
     * Update weather markers on map
     * @param {Object} weatherData - Weather data for current day
     * @param {number} dayIndex - Current day index
     * @param {boolean} showOnlyDry - Show only cities without rain
     */
    updateWeatherMarkers(weatherData, dayIndex, showOnlyDry = false) {
        this.currentWeatherData = weatherData;
        this.currentDayIndex = dayIndex;
        this.showOnlyDry = showOnlyDry;
        
        // Clear existing weather markers
        this.weatherLayer.clearLayers();
        
        if (!weatherData?.previsions) {
            console.warn('MapController: No weather data provided');
            return;
        }
        
        weatherData.previsions.forEach((city) => {
            if (!city.donnees_disponibles) return;
            
            const hasRain = (city.precipitation || 0) > 0;
            
            // Filter based on dry-only setting
            if (showOnlyDry && hasRain) return;
            
            const marker = this.createWeatherMarker(city, hasRain);
            this.weatherLayer.addLayer(marker);
        });
        
        this.emit('weatherMarkersUpdated', {
            dayIndex,
            citiesCount: weatherData.previsions.length,
            visibleCount: this.weatherLayer.getLayers().length
        });
    }
    
    /**
     * Create a weather marker for a city
     * @private
     * @param {Object} city - City weather data
     * @param {boolean} hasRain - Whether city has rain
     * @returns {L.Marker} Leaflet marker
     */
    createWeatherMarker(city, hasRain) {
        // Create custom marker HTML
        const markerHtml = `
            <div class="relative">
                <div class="bg-white rounded-full p-1 shadow-lg border-2 ${hasRain ? 'border-blue-400' : 'border-green-500'}">
                    <div class="w-8 h-8 flex items-center justify-center text-lg">
                        ${this.getWeatherIcon(city, hasRain)}
                    </div>
                </div>
                ${!hasRain ? '<div class="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full"></div>' : ''}
            </div>
        `;
        
        const icon = L.divIcon({
            html: markerHtml,
            className: 'weather-marker',
            iconSize: [36, 36],
            iconAnchor: [18, 18],
            popupAnchor: [0, -18]
        });
        
        const marker = L.marker([city.lat, city.lon], { icon });
        
        // Create popup content
        const popupContent = this.createWeatherPopup(city);
        marker.bindPopup(popupContent, {
            maxWidth: 280,
            className: 'weather-popup'
        });
        
        // Add click handler
        marker.on('click', () => {
            this.emit('weatherMarkerClicked', { city, dayIndex: this.currentDayIndex });
        });
        
        return marker;
    }
    
    /**
     * Get weather icon for city
     * @private
     * @param {Object} city - City data
     * @param {boolean} hasRain - Has rain
     * @returns {string} Emoji icon
     */
    getWeatherIcon(city, hasRain) {
        if (hasRain) {
            if ((city.precipitation || 0) > 10) return '🌧️';
            if ((city.precipitation || 0) > 5) return '🌦️';
            return '☔';
        }
        
        // Clear weather - check temperature and conditions
        const temp = city.temp_max || 20;
        const windSpeed = city.wind_speed || 0;
        
        if (temp > 25 && windSpeed < 15) return '☀️';
        if (temp > 20) return '⛅';
        if (temp > 15) return '☁️';
        return '🌤️';
    }
    
    /**
     * Create weather popup content
     * @private
     * @param {Object} city - City weather data
     * @returns {string} HTML content
     */
    createWeatherPopup(city) {
        const rain = city.precipitation || 0;
        const tempMin = city.temp_min ? Math.round(city.temp_min) : '?';
        const tempMax = city.temp_max ? Math.round(city.temp_max) : '?';
        const windSpeed = city.wind_speed ? Math.round(city.wind_speed) : 0;
        const uvIndex = city.uv_index || 0;
        
        return `
            <div class="space-y-2 p-1">
                <h3 class="font-bold text-lg text-center border-b pb-1">${city.nom}</h3>
                
                <div class="grid grid-cols-2 gap-2 text-sm">
                    <div class="flex items-center">
                        <span class="mr-1">🌡️</span>
                        <span>${tempMin}° - ${tempMax}°C</span>
                    </div>
                    
                    <div class="flex items-center">
                        <span class="mr-1">💧</span>
                        <span>${rain.toFixed(1)} mm</span>
                    </div>
                    
                    ${windSpeed > 20 ? `
                        <div class="flex items-center">
                            <span class="mr-1">💨</span>
                            <span>${windSpeed} km/h</span>
                        </div>
                    ` : ''}
                    
                    ${uvIndex > 5 ? `
                        <div class="flex items-center">
                            <span class="mr-1">☀️</span>
                            <span>UV ${uvIndex}</span>
                        </div>
                    ` : ''}
                </div>
                
                ${rain === 0 ? `
                    <div class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs text-center">
                        ✨ Idéal pour les activités extérieures
                    </div>
                ` : ''}
                
                ${city.lever_soleil && city.coucher_soleil ? `
                    <div class="text-xs text-gray-600 text-center border-t pt-1">
                        🌅 ${new Date(city.lever_soleil).toLocaleTimeString('fr-FR', {hour: '2-digit', minute: '2-digit'})} - 
                        🌇 ${new Date(city.coucher_soleil).toLocaleTimeString('fr-FR', {hour: '2-digit', minute: '2-digit'})}
                    </div>
                ` : ''}
            </div>
        `;
    }
    
    /**
     * Update activity markers on map
     * @param {Array} activities - List of activities to display
     * @param {Set} activeFilters - Active activity type filters
     */
    updateActivityMarkers(activities, activeFilters = new Set()) {
        this.activeActivities = activities;
        this.visibleActivities.clear();
        
        // Clear existing activity markers
        this.activitiesLayer.clearLayers();
        
        activities.forEach((activity) => {
            // Apply filters
            if (!activeFilters.has(activity.type)) return;
            
            const marker = this.createActivityMarker(activity);
            this.activitiesLayer.addLayer(marker);
            this.visibleActivities.add(activity.nom);
        });
        
        this.emit('activityMarkersUpdated', {
            totalActivities: activities.length,
            visibleActivities: this.visibleActivities.size
        });
    }
    
    /**
     * Create an activity marker
     * @private
     * @param {Object} activity - Activity data
     * @returns {L.Marker} Leaflet marker
     */
    createActivityMarker(activity) {
        const icon = this.getActivityIcon(activity.type);
        const color = this.getActivityColor(activity.type);
        
        const markerHtml = `
            <div class="lieu-marker" style="background: ${color}; border: 2px solid white;">
                <span class="text-white">${icon}</span>
            </div>
        `;
        
        const leafletIcon = L.divIcon({
            html: markerHtml,
            className: 'activity-marker',
            iconSize: [32, 32],
            iconAnchor: [16, 16],
            popupAnchor: [0, -16]
        });
        
        const marker = L.marker([activity.lat, activity.lon], { icon: leafletIcon });
        
        // Create popup
        const popupContent = this.createActivityPopup(activity);
        marker.bindPopup(popupContent, {
            maxWidth: 250,
            className: 'activity-popup'
        });
        
        // Add click handler
        marker.on('click', () => {
            this.emit('activityMarkerClicked', { activity });
        });
        
        return marker;
    }
    
    /**
     * Get activity icon
     * @private
     * @param {string} type - Activity type
     * @returns {string} Emoji icon
     */
    getActivityIcon(type) {
        const icons = {
            cascade: '💧',
            thermes: '♨️',
            lac: '🏊',
            plage: '🏖️',
            gorges: '🏔️',
            grotte: '🕳️',
            piscine: '💎',
            vue: '👁️',
            canyon: '🪂'
        };
        return icons[type] || '📍';
    }
    
    /**
     * Get activity color
     * @private
     * @param {string} type - Activity type
     * @returns {string} CSS color
     */
    getActivityColor(type) {
        const colors = {
            cascade: '#3b82f6',
            thermes: '#ef4444',
            lac: '#06b6d4',
            plage: '#f59e0b',
            gorges: '#8b5cf6',
            grotte: '#6b7280',
            piscine: '#14b8a6',
            vue: '#ec4899',
            canyon: '#f97316'
        };
        return colors[type] || '#6b7280';
    }
    
    /**
     * Create activity popup content
     * @private
     * @param {Object} activity - Activity data
     * @returns {string} HTML content
     */
    createActivityPopup(activity) {
        return `
            <div class="space-y-2 p-1">
                <h3 class="font-bold text-center">${this.getActivityIcon(activity.type)} ${activity.nom}</h3>
                <p class="text-sm text-gray-600">${activity.description}</p>
                
                <div class="flex justify-center gap-2 pt-2 border-t">
                    <button class="text-xs bg-blue-500 text-white px-2 py-1 rounded" 
                            onclick="window.mapController.navigateToActivity('${activity.nom}')">
                        🧭 Itinéraire
                    </button>
                    <button class="text-xs bg-green-500 text-white px-2 py-1 rounded" 
                            onclick="window.mapController.addToRoute('${activity.nom}')">
                        ➕ Ajouter
                    </button>
                </div>
            </div>
        `;
    }
    
    /**
     * Fit map to show all visible markers
     */
    fitToMarkers() {
        const allLayers = [
            ...this.weatherLayer.getLayers(),
            ...this.activitiesLayer.getLayers(),
            ...this.routeLayer.getLayers()
        ];
        
        if (allLayers.length === 0) return;
        
        const group = new L.featureGroup(allLayers);
        this.map.fitBounds(group.getBounds(), {
            padding: [20, 20],
            maxZoom: 12
        });
        
        this.emit('mapFittedToMarkers', { 
            markerCount: allLayers.length,
            bounds: group.getBounds()
        });
    }
    
    /**
     * Center map on location
     * @param {number} lat - Latitude
     * @param {number} lon - Longitude
     * @param {number} zoom - Zoom level
     */
    centerOn(lat, lon, zoom = null) {
        this.map.setView([lat, lon], zoom || this.map.getZoom());
        
        this.emit('mapCentered', { lat, lon, zoom });
    }
    
    /**
     * Add route line to map
     * @param {Array} coordinates - Array of [lat, lon] coordinates
     * @param {Object} options - Route styling options
     */
    addRoute(coordinates, options = {}) {
        const routeOptions = {
            color: options.color || '#3b82f6',
            weight: options.weight || 4,
            opacity: options.opacity || 0.8,
            dashArray: options.dashArray || null,
            ...options
        };
        
        const polyline = L.polyline(coordinates, routeOptions);
        this.routeLayer.addLayer(polyline);
        
        // Fit to route if requested
        if (options.fitBounds !== false) {
            this.map.fitBounds(polyline.getBounds(), {
                padding: [10, 10]
            });
        }
        
        this.emit('routeAdded', { 
            coordinates,
            bounds: polyline.getBounds()
        });
        
        return polyline;
    }
    
    /**
     * Clear all routes from map
     */
    clearRoutes() {
        this.routeLayer.clearLayers();
        this.emit('routesCleared');
    }
    
    /**
     * Get current map bounds
     * @returns {Object} Bounds object
     */
    getBounds() {
        return this.map.getBounds();
    }
    
    /**
     * Get current map center
     * @returns {Object} LatLng object
     */
    getCenter() {
        return this.map.getCenter();
    }
    
    /**
     * Get current map zoom
     * @returns {number} Zoom level
     */
    getZoom() {
        return this.map.getZoom();
    }
    
    /**
     * Navigate to activity (placeholder for external routing)
     * @param {string} activityName - Name of activity
     */
    navigateToActivity(activityName) {
        const activity = this.activeActivities.find(a => a.nom === activityName);
        if (!activity) return;
        
        this.emit('navigationRequested', { activity });
        
        // Placeholder - would integrate with routing service
        console.log('Navigation requested to:', activityName);
    }
    
    /**
     * Add activity to route planning
     * @param {string} activityName - Name of activity
     */
    addToRoute(activityName) {
        const activity = this.activeActivities.find(a => a.nom === activityName);
        if (!activity) return;
        
        this.emit('activityAddedToRoute', { activity });
    }
    
    /**
     * Toggle map layer visibility
     * @param {string} layerName - Name of layer to toggle
     */
    toggleLayer(layerName) {
        const layers = {
            weather: this.weatherLayer,
            activities: this.activitiesLayer,
            routes: this.routeLayer
        };
        
        const layer = layers[layerName];
        if (!layer) return;
        
        if (this.map.hasLayer(layer)) {
            this.map.removeLayer(layer);
        } else {
            this.map.addLayer(layer);
        }
        
        this.emit('layerToggled', { 
            layerName,
            visible: this.map.hasLayer(layer)
        });
    }
    
    /**
     * Simple event emitter
     * @param {string} event - Event name
     * @param {Object} data - Event data
     */
    emit(event, data = {}) {
        const customEvent = new CustomEvent(`map:${event}`, {
            detail: { ...data, timestamp: Date.now() }
        });
        document.dispatchEvent(customEvent);
    }
    
    /**
     * Listen to map events
     * @param {string} event - Event name
     * @param {Function} handler - Event handler
     */
    on(event, handler) {
        document.addEventListener(`map:${event}`, handler);
    }
    
    /**
     * Invalidate map size (useful after container resize)
     */
    invalidateSize() {
        if (this.map) {
            this.map.invalidateSize();
        }
    }
    
    /**
     * Clean up resources
     */
    destroy() {
        if (this.map) {
            this.map.remove();
            this.map = null;
        }
        
        this.weatherLayer = null;
        this.activitiesLayer = null;
        this.routeLayer = null;
        this.eventHandlers.clear();
        
        console.log('MapController: Cleaned up');
    }
}

// Export for use in main application
export default MapController;